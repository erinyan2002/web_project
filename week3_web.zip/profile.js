document.addEventListener("DOMContentLoaded", () => {
    const editButton = document.getElementById("edit-button");
    const nameElement = document.getElementById("name");
    const profileInfo = document.querySelector(".profile-info");

    editButton.addEventListener("click", () => {
        // 이름 입력 창 생성
        const input = document.createElement("input");
        input.type = "text";
        input.id = "name-input";
        input.value = nameElement.textContent; // 현재 이름 가져오기
        profileInfo.insertBefore(input, editButton); // 버튼 위에 추가

        // 버튼 숨기기
        editButton.style.display = "none";

        // 입력창에서 엔터를 누르면 이름 저장
        input.addEventListener("keypress", (event) => {
            if (event.key === "Enter") {
                const newName = input.value.trim();
                if (newName) {
                    nameElement.textContent = newName; // 이름 업데이트
                }
                input.remove(); // 입력창 제거
                editButton.style.display = "block"; // 버튼 다시 표시
            }
        });

        // 입력창 외부 클릭 시 변경 취소
        document.addEventListener(
            "click",
            (event) => {
                if (event.target !== input && event.target !== editButton) {
                    input.remove();
                    editButton.style.display = "block";
                }
            },
            { once: true }
        );
    });
});
