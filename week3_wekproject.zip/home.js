document.addEventListener("DOMContentLoaded", function () {
    const fileInput = document.getElementById("fileInput");
    const fileTitle = document.getElementById("fileTitle");
    const fileDescription = document.getElementById("fileDescription");
    const uploadBtn = document.getElementById("uploadBtn");
    const uploadedGallery = document.getElementById("uploadedGallery");

    // 업로드된 사진 데이터를 저장할 배열
    let uploadedPhotos = [];

    // 업로드 버튼 클릭 이벤트
    uploadBtn.addEventListener("click", function () {
        const file = fileInput.files[0];
        const title = fileTitle.value.trim();
        const description = fileDescription.value.trim();

        if (!file) {
            alert("사진 파일을 선택해주세요!");
            return;
        }

        if (!title || !description) {
            alert("제목과 설명을 입력해주세요!");
            return;
        }

        const reader = new FileReader();

        reader.onload = function () {
            // 사진 데이터 객체 생성
            const photoData = {
                src: reader.result,
                title: title,
                description: description,
            };

            // 배열에 저장
            uploadedPhotos.push(photoData);

            // 갤러리 렌더링
            renderGallery();
        };

        reader.readAsDataURL(file);

        // 입력 필드 초기화
        fileInput.value = "";
        fileTitle.value = "";
        fileDescription.value = "";
    });

    // 갤러리 렌더링 함수
    function renderGallery() {
        uploadedGallery.innerHTML = ""; // 기존 내용을 초기화

        uploadedPhotos.forEach((photo, index) => {
            const photoDiv = document.createElement("div");
            photoDiv.className = "photo-item";

            photoDiv.innerHTML = `
                <img src="${photo.src}" alt="${photo.title}" />
                <h3>${photo.title}</h3>
                <p>${photo.description}</p>
                <button onclick="deletePhoto(${index})">삭제</button>
            `;

            uploadedGallery.appendChild(photoDiv);
        });
    }

    // 사진 삭제 함수
    window.deletePhoto = function (index) {
        uploadedPhotos.splice(index, 1);
        renderGallery();
    };
});
